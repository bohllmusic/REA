<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <link rel="stylesheet" href="../View/digginNuggets1.css">
    <link rel="icon" type="image/png" href="../images/kisspng-chicken-nugget-fried-chicken-chicken-fingers-fast-chicken-nuggets-clipart-5a8b06b4effbd2.362129591519060660983.png" />
</head>
<body>
    <header class="shdw">
        <h1><img src="../images/kisspng-chicken-nugget-fried-chicken-chicken-fingers-fast-chicken-nuggets-clipart-5a8b06b4effbd2.362129591519060660983.png" alt="" id="logoHdr"><a href="">Diggin' Nuggets</a></h1>
        <H2>Accueil</H2>
        <div><img src="../images/kisspng-magnifying-glass-computer-icons-clip-art-magnifying-glass-ico-5ab151010c51b2.1038397015215700490505 (1).png" alt="" id="loupe"><input type="text" placeholder="search..." id="search"></div>
    </header>
    <nav class="shdw"><a href="" class="navLinks">S'inscrire</a><a href="" class="navLinks">Se connecter</a><a href=""class="navLinks">Nous contacter</a></nav>
    <container>
        <span class="shdw">
            <a href="" class="spanLinks">House</a>
            <a href="" class="spanLinks">article recent</a>
            <a href="" class="spanLinks">Drum and bass</a>
            <a href="" class="spanLinks">BASS</a>
            <a href="" class="spanLinks">Dubstep</a>
            <a href="" class="spanLinks">Jungle</a>
            <a href="" class="spanLinks">Breakbeat</a>
            <a href="" class="spanLinks">Electro</a>

        </span>
        <span class= "shdw">
            <div class="posts">
                <article>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/3A544FWzU1I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <h3><img class="userImg" src="../REA3_site/images/kisspng-computer-icons-user-clip-art-user-5abf13db5624e4.1771742215224718993529.png" alt=""><a href="">User pseudo:</a> </h3>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt reprehenderit aliquam commodi, delectus nam eum placeat rerum, tempora, iusto sint illum eligendi quas sequi pariatur. Explicabo recusandae est velit commodi!    #HOUSE
                </article>
            </div>
            <div class="posts">
                <article>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/a8KOpEWuwDw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <h3><img class="userImg" src="../REA3_site/images/kisspng-computer-icons-user-clip-art-user-5abf13db5624e4.1771742215224718993529.png" alt=""><a href="">User pseudo:</a> </h3>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt reprehenderit aliquam commodi, delectus nam eum placeat rerum, tempora, iusto sint illum eligendi quas sequi pariatur. Explicabo recusandae est velit commodi!    #GARAGE
                </article>
            </div>
            <div class="posts">
                <article>
                    <iframe width="560" height="315" src="https://www.youtube.com/embed/SyTPMr0AQXs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    <h3><img class="userImg" src="../REA3_site/images/kisspng-computer-icons-user-clip-art-user-5abf13db5624e4.1771742215224718993529.png" alt=""><a href="">User pseudo:</a> </h3>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt reprehenderit aliquam commodi, delectus nam eum placeat rerum, tempora, iusto sint illum eligendi quas sequi pariatur. Explicabo recusandae est velit commodi!    #DNB
                </article>
            </div> 

        </span>

    </container>
</body>
</html>