<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>House</title>
    <link rel="stylesheet" href="../digginNuggets1.css">
</head>
<body>
    <header class="shdw">
        <h1><img src="../REA3/images/kisspng-chicken-nugget-fried-chicken-chicken-fingers-fast-chicken-nuggets-clipart-5a8b06b4effbd2.362129591519060660983.png" alt="" id="logoHdr"><a href="../">Diggin' Nuggets</a></h1>
        <h2>Inscription</h2>
        <div><img src="../REA3/images/kisspng-magnifying-glass-computer-icons-clip-art-magnifying-glass-ico-5ab151010c51b2.1038397015215700490505 (1).png" alt="" id="loupe"><input type="text" placeholder="search..." id="search"></div>
    </header>

    <nav class="shdw"><a href="" class="navLinks">Accueil</a><a href="" class="navLinks">Se connecter</a><a href=""class="navLinks">Nous contacter</a></nav>

    <container>
        <span class="shdw">
            <a href="house.html" class="spanLinks">House</a>
            <a href="" class="spanLinks">Techno</a>
            <a href="" class="spanLinks">Drum and bass</a>
            <a href="" class="spanLinks">BASS</a>
            <a href="" class="spanLinks">Dubstep</a>
            <a href="" class="spanLinks">Jungle</a>
            <a href="" class="spanLinks">Breakbeat</a>
            <a href="" class="spanLinks">Electro</a>

        </span>
        <span class="shdw">
        </span>

    </container>
</body>